# Chipxi Office — source + cloud APK build starter

Chipxi Office is a mobile-first React/Vite workspace intended to host Univer-powered office editors. This repository includes the workspace UI and a GitHub Actions workflow that can package the web build into a **debug Android APK** without Android Studio on your phone.

## What is included now

- Responsive Chipxi Office workspace UI for phone and desktop browsers.
- Create-file dialog, file list, search, favorites, and localStorage for file-list metadata.
- Capacitor configuration (`appId: app.chipxi.office`, app name `Chipxi Office`).
- GitHub Actions workflow: `.github/workflows/build-android-apk.yml` builds and uploads a debug APK artifact.

## Honest feature status

This source is a buildable packaging starter, **not yet a complete office suite**. The current dashboard does not yet embed the actual Univer editors. Docs/Sheets editor initialization, Slides and PDF integrations, document-content persistence/import/export, backend storage, and collaboration remain follow-up implementation work. Univer's official docs distinguish open Web SDK packages from `@univerjs-pro` products; Slides and PDFs use Pro packages and may require a suitable client license. Do not treat the dashboard's file-list localStorage as saving actual document contents.

Official references:
- Docs setup: https://docs.univer.ai/guides/docs/getting-started/installation
- Sheets setup: https://docs.univer.ai/guides/sheets/getting-started/installation
- Slides: https://docs.univer.ai/guides/slides
- PDFs: https://docs.univer.ai/guides/pdfs

## Run in an online IDE

1. Upload this ZIP to a GitHub repository (instructions below), or import the source into an online Node.js IDE that supports Vite.
2. Use Node.js 22 or newer.
3. Run `npm install`.
4. Run `npm run dev -- --host 0.0.0.0`.
5. Run `npm run build` to create `dist/`.

## Get a debug APK using only your phone

The APK is built by GitHub Actions in the cloud. You need a GitHub account and must upload these source files to a repository you control.

1. Open https://github.com in your phone browser and sign in.
2. Create a new repository named `chipxi-office` (public or private).
3. Upload the contents of this ZIP to the repository root. Make sure `.github/workflows/build-android-apk.yml` is included. GitHub's web file upload can be awkward for many files; if it fails, use GitHub Codespaces or another browser IDE connected to the repository.
4. Open the repository's **Actions** tab and select **Build Chipxi Office Android APK**.
5. If it has not started automatically, tap **Run workflow**.
6. Wait for the workflow to finish successfully, open that run, scroll to **Artifacts**, and download `chipxi-office-debug-apk`.
7. Extract the downloaded artifact ZIP to obtain `app-debug.apk`, then tap it to install. Android may ask you to allow installs from that browser/file manager.

The workflow produces a **debug APK**, not a Play Store release. It is not signed with your own release key. Keep your signing key private and do not commit it to GitHub.

## Build workflow details

The workflow installs dependencies, builds the Vite app, generates the Android platform with Capacitor, syncs `dist/`, runs Gradle `assembleDebug`, and uploads `android/app/build/outputs/apk/debug/app-debug.apk` as a downloadable artifact. This cloud build has not been executed from this chat; the first GitHub Actions run is the actual verification.

## Next engineering steps

1. Pin and test the exact compatible Univer package versions.
2. Integrate and test Docs and Sheets Web SDK editors, including mobile/touch behavior.
3. Add Slides/PDF only after confirming licensing and package access.
4. Persist actual editor snapshots and implement file import/export.
5. Add authentication and server-backed storage only if cloud sync is needed.
6. Test the APK on Android 16 and fix WebView keyboard, selection, file-picker, and navigation behavior.

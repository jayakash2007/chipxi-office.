# Android packaging

This project uses Capacitor. The Android project is generated in the cloud by `.github/workflows/build-android-apk.yml` so the user does not need Android Studio on their phone.

For local development on a computer, install dependencies, run `npm run build`, then `npx cap add android` (first time) and `npx cap sync android`. Open the generated `android/` directory in Android Studio or run `cd android && ./gradlew assembleDebug` with a compatible Java/Android SDK installation.

See `APK_BUILD_ON_PHONE.md` for the phone-only GitHub Actions process. A generated APK has not been verified until a successful Actions run completes.

# Integration plan

## Phase 1 — verify the editor SDK

Use the official Univer documentation and examples to verify the exact package versions, supported editor presets, licensing, peer dependencies, import/export formats, and Android WebView support. Keep the package versions pinned. Do not infer APIs from old snippets.

Official starting points:
- https://docs.univer.ai/llms-full.txt
- https://docs.univer.ai/guides/llms.txt
- https://docs.univer.ai/reference/llms.txt
- https://docs.univer.ai/guides/sheets.md
- https://docs.univer.ai/guides/docs.md
- https://docs.univer.ai/guides/slides.md
- https://docs.univer.ai/guides/pdfs.md
- https://github.com/dream-num/univer-collaboration-examples

## Phase 2 — connect editing engines

1. Integrate the verified Sheets editor and test on desktop and Android WebView.
2. Integrate the verified Docs editor and test import/export.
3. Integrate Slides after verifying its current availability and API surface.
4. Add a supported PDF viewer/renderer and export/print flow; a PDF file icon alone is not a PDF engine.
5. Replace dashboard notices with real editor routes and real save/load operations.

## Phase 3 — persistence and Android packaging

1. Define a document model and stable IDs.
2. Implement local document content storage, not just the current dashboard metadata.
3. Add a backend only if cloud sync/accounts are required; protect secrets server-side.
4. Add robust WebView file picker/download handling and Android back/keyboard behavior.
5. Test on Android 16 physical devices, then sign and distribute the APK.

## Phase 4 — collaboration

Use the official collaboration SDK/examples only after the basic editors and persistence work. Plan for authentication, authorization, concurrent editing, conflict recovery, and operational monitoring.

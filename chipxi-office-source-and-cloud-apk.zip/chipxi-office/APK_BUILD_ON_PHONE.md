# Build Chipxi Office APK from an Android phone

## One-time setup
1. Create/sign in to a GitHub account at https://github.com.
2. Create a repository named `chipxi-office`.
3. Upload the complete contents of this project ZIP to the repository root, including the hidden `.github` folder.

## Build
1. Open the repository's **Actions** tab.
2. Choose **Build Chipxi Office Android APK**.
3. Tap **Run workflow** if no run has started.
4. Wait until the job is green/successful.
5. Open that workflow run, find **Artifacts**, and download `chipxi-office-debug-apk`.
6. Extract the artifact ZIP; install `app-debug.apk`.

If the workflow fails, open the failed run and inspect the first red step. Common causes include a package version incompatibility or Android/Gradle build change. Send the error log for debugging.

This cloud workflow is configured but has not yet been run, so an APK file is not attached to this source archive. The result is a debug APK. The app itself is still a workspace starter; real Univer editors are a separate integration step.
